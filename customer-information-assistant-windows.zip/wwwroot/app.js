// Product-local focus behavior; no networking or business operations.
window.customerTheme = mode => {
    const resolved = mode === 'system' ? (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark') : mode;
    document.documentElement.dataset.theme = resolved === 'light' ? 'light' : 'dark';
    window.customerThemeMode = mode;
};
matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => { if (window.customerThemeMode === 'system') window.customerTheme('system'); });
(() => {
    let previousFocus = null;
    let lastOverlay = null;
    const focusables = element => [...element.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href]')].filter(e => e.getClientRects().length);
    const observer = new MutationObserver(() => {
        const overlay = document.querySelector('.app-dialog') || document.querySelector('.context-menu');
        if (overlay && overlay !== lastOverlay) {
            if (!lastOverlay) previousFocus = document.activeElement;
            lastOverlay = overlay;
            (overlay.querySelector('[autofocus]') || focusables(overlay)[0])?.focus();
        } else if (!overlay && lastOverlay) {
            lastOverlay = null;
            if (previousFocus?.isConnected) previousFocus.focus();
            previousFocus = null;
        }
    });
    observer.observe(document.getElementById('app'), {childList: true, subtree: true});
    const resizeDraft = field => {
        if (!field?.matches('.gateway-compose-input textarea')) return;
        field.style.height = '38px';
        field.style.height = Math.min(160, Math.max(38, field.scrollHeight + 2)) + 'px';
    };
    document.addEventListener('input', event => requestAnimationFrame(() => resizeDraft(event.target)));
    window.addEventListener('resize', () => document.querySelectorAll('.gateway-compose-input textarea').forEach(resizeDraft));
    document.addEventListener('dragstart', event => {
        if (event.target.closest('.greeting-row')) event.dataTransfer?.setData('text/plain', 'greeting-reorder');
    });
    let contactDrag = null;
    const setContactWidth = width => {
        const app = document.querySelector('.app:not(.feature-shell)');
        if (!app) return;
        width = Math.round(Math.max(160, Math.min(360, app.clientWidth - 400, width)));
        document.documentElement.style.setProperty('--contact-width', width + 'px');
        try { localStorage.setItem('contactWidthV42', String(width)); } catch {}
    };
    try { const width = Number(localStorage.getItem('contactWidthV42')); if (width >= 160 && width <= 360) document.documentElement.style.setProperty('--contact-width', width + 'px'); } catch {}
    document.addEventListener('pointerdown', event => {
        if (!event.target.matches('.contact-resize')) return;
        const sidebar = event.target.closest('.sidebar');
        contactDrag = { x: event.clientX, width: sidebar.getBoundingClientRect().width, target: event.target };
        event.target.setPointerCapture(event.pointerId); event.preventDefault();
    });
    document.addEventListener('pointermove', event => { if (contactDrag) setContactWidth(contactDrag.width + event.clientX - contactDrag.x); });
    document.addEventListener('pointerup', () => contactDrag = null);
    document.addEventListener('pointercancel', () => contactDrag = null);
    document.addEventListener('keydown', event => { if (event.target.matches('.contact-resize') && ['ArrowLeft','ArrowRight'].includes(event.key)) { event.preventDefault(); setContactWidth(event.target.closest('.sidebar').getBoundingClientRect().width + (event.key === 'ArrowRight' ? 10 : -10)); } });
    document.addEventListener('keydown', event => {
        if ((event.ctrlKey || event.metaKey) && event.key === 'Enter' && document.activeElement?.id === 'greeting-draft') {
            event.preventDefault();
            document.querySelector('.greeting-editor-actions .primary:not(:disabled)')?.click();
            return;
        }
        const dialog = document.querySelector('.app-dialog');
        const menu = document.querySelector('.context-menu');
        const overlay = dialog || menu;
        if (!overlay) return;
        const items = focusables(overlay);
        if (event.key === 'Escape') {
            event.preventDefault();
            if (menu) document.querySelector('.menu-dismiss')?.click();
            else (dialog.querySelector('header button[aria-label]') || items.find(b => b.textContent.trim() === '取消'))?.click();
        } else if (event.key === 'Tab' && items.length) {
            const index = items.indexOf(document.activeElement);
            if (event.shiftKey && index <= 0) { event.preventDefault(); items[items.length - 1].focus(); }
            else if (!event.shiftKey && (index < 0 || index === items.length - 1)) { event.preventDefault(); items[0].focus(); }
        } else if (menu && ['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key) && items.length) {
            event.preventDefault();
            const index = items.indexOf(document.activeElement);
            const next = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : (index + (event.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
            items[next].focus();
        }
    });
})();
